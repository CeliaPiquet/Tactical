 #ifndef DEF_PARAMS

    #define DEF_PARAMS
        #include <stdlib.h>
        #include <stdio.h>
        #include <SDL2/SDL.h>
        #include <SDL2/SDL_ttf.h>
        #include <fmod.h>
        #include <string.h>
        #define TILE_SIZE 32
        #define CONF_PATH "../configFile.conf"

        //structures
        typedef struct Tile{
            int id;
            char* path;
            char* name;
            SDL_Texture* texture;
            struct Tile* next;
            struct Tile* previous;
        } Tile;

        typedef struct TilesList{
            struct Tile *first;
            struct Tile *last;
        } TilesList;

        typedef struct Parameters{
            int mapHeight;
            int mapWidth;
        } Parameters;

        //from editor.c
        void displayActualTile(Tile* actualTile, SDL_Renderer* pRenderer, Parameters* myParameters);
        void menu(SDL_Renderer* pRenderer, Parameters* myParameters);
        int isEventInMap(SDL_Event * event, Parameters* myParameters);
        int** newMap();
        void updateScreen(int ** map, SDL_Renderer *pRenderer, TilesList* tilesList, Tile* actualTile, Parameters* myParameters);
        void freeMap(int ** map);
        TilesList* generateList();
        void createTextures(TilesList* tilesList, SDL_Renderer* pRenderer);
        int mouseButtonDown(SDL_Event *event, int ** map,Tile* actualTile, SDL_Renderer * pRenderer,TilesList* tilesList, int* clickingLeft, int* clickingRight,Parameters* myParameters);
        int mouseButtonUp(SDL_Event *event, int* clickingLeft, int* clickingRight, Parameters* myParameters);
        int mouseMotion(SDL_Event *event, int ** map,Tile* actualTile, SDL_Renderer * pRenderer,TilesList* tilesList, int clickingLeft, int clickingRight, Parameters* myParameters);
        void editor(Parameters* myParameters);

        //from map.c
        int isMapCorrect(int** map, Parameters* myParameters);
        int saveMapFile(int** map, char* fileName, Parameters* myParameters);
        int isEmptyTile(int** map, Parameters* myParameters);
        int saveMap(int** map, Parameters* myParameters);
        int isAbsentHQ1(int** map, Parameters* myParameters);
        int isMultipleHQ(int** map, Parameters * myParameters);
        int isAbsentHQ2(int** map, Parameters* myParameters);


        //from list.c
        void freeTilesList(TilesList* list);
        Tile * getTileById(TilesList* list, int x);
        TilesList* init(char* nameFirst, char* pathFirst);
        int toPush(TilesList *list, char* newName, char* newPath);
        void toPrint(TilesList* list);

        //from sound.c
        void loadSound();

        //from errors.c
        void writeMessage(char *errorMessage, SDL_Renderer *pRendererError);
        void newWindow(char* errorMessage, char* displayTYPE);

        //from input.c
        void displayInput(char * input, SDL_Renderer* pRenderer);
        int inputWindow(char* fileName, char* title);
        int inputIsOk(char* input);

        //from openMap.c
        int isFileExisting(char* fileName);
        int ** openMap(Parameters* myParameters);

 #endif // DEF_PARAMS
