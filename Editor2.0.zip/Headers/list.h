#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>

typedef struct Tile{
    int id;
    char* path;
    SDL_Texture* texture;
    char* name;
    struct Tile* next;
    struct Tile* previous;
} Tile;

typedef struct TilesList{
    struct Tile *first;
    struct Tile *last;
} TilesList;

TilesList *init();
int toPush(TilesList* list, char* newName, char* newPath);


