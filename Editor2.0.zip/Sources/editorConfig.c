#include "../Headers/editor.h"

int setEditorParameters(Parameters* myParameters) {

    return 0;
}
