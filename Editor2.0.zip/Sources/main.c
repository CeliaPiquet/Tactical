#include "../Headers/editor.h"


int main( int argc, char * argv[] )
{
    if (SDL_Init(SDL_INIT_VIDEO)){
        fprintf(stdout,"Echec : %s \n", SDL_GetError());
    }
    else{
        Parameters* myParameters = malloc(sizeof(Parameters));

        //default parameters :
        myParameters->mapHeight = 10;
        myParameters->mapWidth = 10;

        //read the configuration file


        //start the editor
        editor(myParameters);

        //loadSound();
    }
    SDL_Quit();

    return 1;
}

