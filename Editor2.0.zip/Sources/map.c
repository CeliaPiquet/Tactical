#include "../Headers/editor.h"

int isMapCorrect(int** map, Parameters* myParameters){            //v�rifier pathfinding
    if (isEmptyTile(map,myParameters )){
        newWindow("Veillez � ne pas laisser de cases vides!","ERREUR");
        return 0;
    }
    if (isAbsentHQ1(map,myParameters)){
        newWindow("Il vous manque un QG bleu","ERREUR");
        return 0;
    }
    if (isAbsentHQ2(map,myParameters)){
        newWindow("Il vous manque un QG rouge","ERREUR");
        return 0;
    }
    if (isMultipleHQ(map, myParameters)){
        newWindow("Il ne faut qu'un QG par joueur","ERREUR");
        return 0;
    }
//    if(notPathfinding(map)){
//        newWindow("Il n'existe pas de chemin entre les deux QG","ERREUR");
//    }
    return 1; //true, the map is correct
}

int isAbsentHQ1(int** map, Parameters* myParameters){
    int i, j;
    for (i=0; i<myParameters->mapHeight; i++){
        for (j=0; j<myParameters->mapWidth; j++){
            if (map[i][j] == 1){
                return 0; //false, HQ1 is not absent
            }
        }
    }
    return 1; //true, HQ1 is absent
}

int isMultipleHQ(int** map, Parameters * myParameters){
    int i, j;
    int isBlue = 0;
    int isRed = 0;
    for (i=0; i<myParameters->mapHeight; i++){
        for (j=0; j<myParameters->mapWidth; j++){
            if (map[i][j] == 1){
                isBlue ++;
            }
            if (map[i][j] == 2){
                isRed ++;
            }
        }
    }
    if (isRed>1 || isBlue>1){
        return 1; //true, there is multiple HQ
    }
    return 0;
}

int isAbsentHQ2(int** map, Parameters* myParameters){
    int i, j;
    for (i=0; i<myParameters->mapHeight; i++){
        for (j=0; j<myParameters->mapWidth; j++){
            if (map[i][j] == 2){
                return 0; //false, HQ2 is not absent
            }
        }
    }
    return 1; //true, HQ2 is absent
}

int isEmptyTile(int** map, Parameters* myParameters){
    int i, j;
    for (i=0; i<myParameters->mapHeight; i++){
        for (j=0; j<myParameters->mapWidth; j++){
            if (map[i][j] == 0){
                return 1; //true, there is at least one empty tile
            }
        }
    }
    return 0; //false, there is not empty tile
}

int saveMap(int** map, Parameters* myParameters){
    char fileName[255];
    if (!isMapCorrect(map,myParameters)) {
        return 0;
    }
    inputWindow(fileName,"Nouvelle Map - Sauvegarde");
    if(fileName!= NULL){
        while (isFileExisting(fileName)){
            newWindow("Un fichier avec le m�me nom existe d�j�","ERREUR");
            inputWindow(fileName,"Nouvelle Map - Sauvegarde");
        }
        if(saveMapFile(map,fileName,myParameters)!=0){
            newWindow("Votre map a bien �t� sauvegard�e !","SAUVEGARDE REUSSIE");
        }
        else {
            newWindow("Erreur lors de la sauvegarde","ERREUR");
            return 0;
        }
    }
    else {
        newWindow("Erreur lors de la sauvegarde","ERREUR");
    }
    return 1;
}

int saveMapFile(int** map, char* fileName, Parameters* myParameters){  //rajouter la taille de MAP_HEIGHT et MAP_WIDTH
    FILE *file = fopen(fileName,"wb");
    int i,j,x;
    if (file != NULL){
        x = myParameters->mapHeight;
        fwrite(&x, sizeof(int), 1, file);
        x = myParameters->mapWidth;
        fwrite(&x, sizeof(int), 1, file);
        for (i=0; i<myParameters->mapHeight; i++){
            for(j=0; j<myParameters->mapWidth; j++){
                fwrite(&(map[i][j]), sizeof(int), 1, file);
            }
        }
        fclose(file);
        return 1;
    }
    return 0;
}





