#include "../Headers/editor.h"


void displayActualTile(Tile* actualTile, SDL_Renderer* pRenderer, Parameters* myParameters){
    int windowWidth = TILE_SIZE*myParameters->mapHeight;
    Tile* next, *previous;
    next = actualTile->next;
    previous = actualTile->previous;
    SDL_Rect posPrev, posAct, posNext;

    posPrev.x = windowWidth + 10;
    posPrev.y = 320 - TILE_SIZE - 10;
    posPrev.h = TILE_SIZE;
    posPrev.w = TILE_SIZE;

    posAct.x = posPrev.x + 106+ TILE_SIZE;
    posAct.y = 320 - TILE_SIZE - 10;
    posAct.h = TILE_SIZE;
    posAct.w = TILE_SIZE;

    posNext.x =  posAct.x + 106;
    posNext.y = 320 - TILE_SIZE - 10;
    posNext.h = TILE_SIZE;
    posNext.w = TILE_SIZE;

    SDL_RenderCopy(pRenderer, previous->texture , NULL,&posPrev);
    SDL_RenderCopy(pRenderer, actualTile->texture , NULL,&posAct);
    SDL_RenderCopy(pRenderer, next->texture , NULL,&posNext);
}

int isEventInMap(SDL_Event * event, Parameters* myParameters){
    int windowWidth = TILE_SIZE*myParameters->mapHeight;
    int windowHeight = TILE_SIZE*myParameters->mapWidth;
    if (event->button.x < windowWidth && event->button.y < windowHeight){
        return 1;
    }
    return 0;
}

int** newMap(Parameters* myParameters){
    int i;
    int ** map;
    map = malloc(myParameters->mapHeight * sizeof(int*));
    if (map != NULL) {
        for (i=0; i < myParameters->mapHeight; i++) {
            map[i] = calloc(myParameters->mapWidth, sizeof(int));
            if (map[i] == NULL){
                return NULL;
            }
        }
        return map;
    }
    return NULL;
}

void updateScreen(int ** map, SDL_Renderer *pRenderer, TilesList* tilesList, Tile* actualTile, Parameters* myParameters){
    int i, j;
    SDL_Rect position;
    Tile* tile;
    for (i = 0 ; i < myParameters->mapHeight ; i++){
        for (j = 0 ; j < myParameters->mapWidth ; j++){
            position.x = i * TILE_SIZE;
            position.y = j * TILE_SIZE;
            position.w = TILE_SIZE;
            position.h = TILE_SIZE;
            if (map[i][j] != 0){
                tile = getTileById(tilesList, map[i][j]);
                SDL_RenderCopy(pRenderer, tile->texture, NULL, &position);
            }
        }
    }
    menu(pRenderer, myParameters);
    displayActualTile(actualTile, pRenderer, myParameters);
    SDL_RenderPresent(pRenderer);

}

void freeMap(int ** map) {
    int i=0;
    if (map != NULL){
        while (map[i]!= NULL){ //we are not using a for loop because we don't know the size of the map
            free(map[i]);
            i ++;
        }
    }
    free(map);
}

void createTextures(TilesList* tilesList, SDL_Renderer* pRenderer){
    Tile* actualTile = tilesList->first;
    SDL_Surface* tileSurface = NULL;
    SDL_Texture* tileTexture = NULL;
    do {
        tileSurface = SDL_LoadBMP(actualTile->path);
        tileTexture = SDL_CreateTextureFromSurface(pRenderer,tileSurface);
        actualTile->texture = tileTexture;
        actualTile = actualTile->next;
    } while (actualTile != tilesList->first);
    SDL_FreeSurface(tileSurface);
}


int mouseButtonDown(SDL_Event *event, int ** map,Tile* actualTile, SDL_Renderer * pRenderer,TilesList* tilesList, int* clickingLeft, int* clickingRight, Parameters* myParameters){
    if (isEventInMap(event,myParameters)){
        if (event->button.button == SDL_BUTTON_LEFT) {
            map[event->button.x / TILE_SIZE][event->button.y / TILE_SIZE] = actualTile->id;
            updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
            *clickingLeft = 1;
            return 1;
        }

        else if (event->button.button == SDL_BUTTON_RIGHT ) {
            map[event->button.x / TILE_SIZE][event->button.y /TILE_SIZE] = 0;
            updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
            *clickingRight = 1;
            return 1;
        }
    }
    return 0;
}

int mouseButtonUp(SDL_Event *event, int* clickingLeft, int* clickingRight, Parameters* myParameters){
    if (isEventInMap(event, myParameters)){
        if (event->button.button == SDL_BUTTON_LEFT){
            *clickingLeft = 0;
            return 1;
        }
        else if (event->button.button == SDL_BUTTON_RIGHT){
            *clickingRight = 0;
            return 1;
        }
        return 0;
    }
    return 0;
}

int mouseMotion(SDL_Event *event, int ** map,Tile* actualTile, SDL_Renderer * pRenderer,TilesList* tilesList, int clickingLeft, int clickingRight, Parameters* myParameters){
    if (isEventInMap(event, myParameters)){
        if (clickingLeft) {                                                         // in case the click
            map[event->motion.x / TILE_SIZE][event->motion.y / TILE_SIZE] = actualTile->id;
            updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
            return 1;
        }
        else if (clickingRight){                                                    // same for the right click
            map[event->motion.x / TILE_SIZE][event->motion.y / TILE_SIZE] = 0;
            updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
            return 1;
        }
    }
    return 0;
}

void editor(Parameters* myParameters){
    int toContinue = 1;
    int clickingLeft = 0;
    int clickingRight = 0;
    int windowHeight, windowWidth;
    TilesList* tilesList = generateList();
    Tile* actualTile = tilesList->first;
    SDL_Window* screen = NULL;
    SDL_Event event;
    int ** map = newMap(myParameters);
    int ** interMap; //for the open function
    windowHeight = myParameters->mapWidth*TILE_SIZE;
    if (windowHeight<320){
        windowHeight = 320;
    }
    windowWidth = 320 + (myParameters->mapHeight*TILE_SIZE);
    screen = SDL_CreateWindow("New Map",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, windowWidth,windowHeight, SDL_WINDOW_SHOWN);
    if (screen && map && tilesList){
        SDL_Renderer *pRenderer = SDL_CreateRenderer(screen,-1,SDL_RENDERER_ACCELERATED);                                                     // creation of a SDL_Renderer using hardware acceleration (faster)
        if (pRenderer){
            createTextures(tilesList, pRenderer);
            updateScreen(map, pRenderer, tilesList, actualTile, myParameters);                                                                                          //create all the textures from the tiles list
            while (toContinue){
                SDL_WaitEvent(&event);
                switch(event.type){
                        case SDL_WINDOWEVENT :
                            if (event.window.event == SDL_WINDOWEVENT_CLOSE){
                                toContinue = 0;
                            }
                            break;
                        case SDL_MOUSEBUTTONDOWN :
                            mouseButtonDown(&event, map, actualTile, pRenderer, tilesList, &clickingLeft, &clickingRight, myParameters);
                            break;
                        case SDL_MOUSEBUTTONUP:
                            mouseButtonUp(&event, &clickingLeft, &clickingRight, myParameters);
                            break;
                        case SDL_MOUSEMOTION:
                            mouseMotion(&event, map, actualTile, pRenderer, tilesList, clickingLeft, clickingRight, myParameters);
                            break;

                        case SDL_KEYDOWN:
                            switch(event.key.keysym.sym){
                                case SDLK_ESCAPE:
                                    toContinue = 0;
                                    break;
                                case SDLK_RIGHT:
                                    actualTile = actualTile->next;
                                    updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
                                    break;
                                case SDLK_LEFT:
                                    actualTile = actualTile->previous;
                                    updateScreen(map, pRenderer, tilesList, actualTile, myParameters);
                                    break;
                                case SDLK_s:
                                    saveMap(map, myParameters);
                                    break;
                                case SDLK_o:
                                    interMap = openMap(myParameters);
                                    if (interMap != NULL && interMap!=map){
                                        printf("free\n");
                                        freeMap(map); //we free the memory because the newMap may take less memory
                                        map = interMap;
                                        windowHeight = myParameters->mapWidth*TILE_SIZE;
                                        if (windowHeight<320){ //we have the menu with a constant size of 320x320
                                            windowHeight = 320;
                                        }
                                        windowWidth = 320 + (myParameters->mapHeight*TILE_SIZE);
                                        SDL_SetWindowSize(screen,windowWidth,windowHeight);
                                    }
                                    updateScreen(map, pRenderer, tilesList, actualTile, myParameters); //we update with the new map
                                    break;
                            }
                            break;
                    }
                    //clean the screen after each event
                    SDL_RenderClear(pRenderer);
            }
            freeMap(map);
            SDL_DestroyRenderer(pRenderer);
            freeTilesList(tilesList);
        }
    }
}
