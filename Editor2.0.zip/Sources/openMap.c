#include "../Headers/editor.h"

int** copyMapFromFile(char* fileName, Parameters* myParameters){
    printf("in copyMapFromFile\n");
    FILE *file = fopen(fileName,"rb");
    int i,j;
    int width, height;
    int** newMap;
    if (file){
            
        if (fread( &height,sizeof(int),1, file)==1){
            myParameters->mapHeight = height;
            printf("height = %d\n", myParameters->mapHeight);
        } else {
            fclose(file);
            return NULL;
        }
        if (fread( &width,sizeof(int),1, file)==1){
            myParameters->mapWidth = width;
            printf("width = %d\n", myParameters->mapWidth);
        } else {
            fclose(file);
            return NULL; 
        }


        if (myParameters->mapHeight && myParameters->mapWidth){
            newMap = malloc(sizeof(int*)*myParameters->mapHeight);
            if (newMap!=NULL){
                for (i=0; i<myParameters->mapHeight; i++){
                    newMap[i]= calloc(sizeof(int),myParameters->mapWidth);
                    if (newMap[i] == NULL){
                        fclose(file);
                        return NULL; //if one allocation doesn't work we have to quit
                    }
                }
                //copying the saveMapFile in the newMap
                for (i = 0; i < myParameters->mapHeight; i++){
                    for (j = 0; j < myParameters->mapWidth; j++){
                        if(fread(&(newMap[i][j]),sizeof(int),1, file)!=1){
                            fclose(file);
                            return NULL;
                        }
                    }
                }

                fclose(file);
                return newMap;
            }
        }
        fclose(file);
        return NULL;
    }
    return NULL;
}
int isFileExisting(char* fileName){
    FILE *file = fopen(fileName,"r");
    if (file != NULL){
        fclose(file);
        return 1;
    }
    return 0;
}

int** openMap(Parameters* myParameters){
    char fileName[255];
    if (inputWindow(fileName, "Ouvrir map déjà existante") && fileName != NULL){
        if(!isFileExisting(fileName)){
            newWindow("Le fichier n'existe pas","ERREUR");
            return NULL;
        }
        else{
            return copyMapFromFile(fileName,myParameters);

        }
    }
    return NULL;
}

//for checking
void displayMap(int** map, Parameters* myParameters){
    if (map){
        for(int i=0; i<myParameters->mapHeight; i++){
            for (int j=0; j<myParameters->mapWidth; j++){
                printf("map[%d][%d] = %d\n", i, j, map[i][j]);
            }
        }
    }
}
