#include "game.h"

void game(GameParameters gameParameters, char *mapPath) {
    int error;
    char **simpleMap;

    error = readMap(mapPath, &simpleMap);


    if (error) {
        printf("\n%s n'est pas valide\n", mapPath);
    } else {
        printf("\n%s valide\n", mapPath);
    }
}

