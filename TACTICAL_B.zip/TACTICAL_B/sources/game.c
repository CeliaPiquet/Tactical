#include "game.h"

void game(GameParameters gameParameters, char *mapPath) {
    int imgFlags;
    int error;
    Tile **map;
    int turnCounter = 1;
    char endGame = 0;
    char mapHeight, mapWidth;
    int wallet1, wallet2;
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Rect position;
    SDL_Texture **mapTextureArray;
    UIElement *uiTextureArray;

    TTF_Init();
    imgFlags = IMG_INIT_PNG; 
    if( !( IMG_Init( imgFlags ) & imgFlags ) ) { 
        printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
    }


    error = readMap(mapPath, &map, &gameParameters);




    if (error) {
        printf("\n%s n'est pas valide\n", mapPath);
    } else {
        printf("\n%s valide\n", mapPath);
    }

    window = SDL_CreateWindow("TACTICAL",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, gameParameters.mapWidth * TILE_SIZE + UI_WIDTH, gameParameters.mapHeight * TILE_SIZE + 200, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);

    wallet1 = gameParameters.initialResources1;
    wallet2 = gameParameters.initialResources2;


    initiateMapTextures(renderer, &mapTextureArray);


    initiateUI(renderer, &uiTextureArray);

    while ( (turnCounter <= gameParameters.maxTurn || gameParameters.maxTurn == 0) && !endGame ) {
        endGame = turn(turnCounter, gameParameters, 1, &map, &wallet1, renderer, &uiTextureArray, mapTextureArray);
        if(endGame) break;
        endGame = turn(turnCounter, gameParameters, 2, &map, &wallet2, renderer, &uiTextureArray, mapTextureArray);
        if(endGame) break;
        turnCounter++;
        printf("turn : %d\twalletJ_1 : %d\twalletJ_2 : %d\n", turnCounter, wallet1, wallet2);
    }


    // TODO:
    if (endGame == 1) {
        // game has actually ended
    } else if (endGame == 2) {
        // save the game
    } else if (endGame == -1) {
        // just sdl quit with no score nor save
    }


    freeMap(gameParameters.mapHeight, gameParameters.mapWidth, &map);

    destroyTextures(&mapTextureArray, &uiTextureArray);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
}

// check if player qg is empty and his wallet isnt
char isRecrutingPossible (Tile **map, Job unitToRecruit, int wallet, char playerId, GameParameters parameters) {
    return (isRecruitTileNotOccupied(map, parameters.mapHeight, parameters.mapWidth, playerId) && isRecruitAffordable(unitToRecruit, wallet));
}


// reads map and check if QG tile Free of unit
char isRecruitTileNotOccupied(Tile **map, int height, int width, char playerId) {
    int i, j;
    
    for( i = 0; i < height; i++)
    {
        for( j = 0; j < width; j++)
        {
            if (map[i][j].type == playerId) {
                return (map[i][j].unit == NULL);
            }
        }
    }

    return 0; // shouldnt, map is tested so one tile is equal to player id
}

char isRecruitAffordable(Job unitToRecruit, int wallet) {
    return (wallet - unitToRecruit.cost >= 0);
}

void changeJobToRecruit(char jobId, Job *selectedJob) {
    
    switch (jobId)
    {
        case 1:
            selectedJob->jobId = 1;
            strcpy(selectedJob->name, "Guerrier");
            selectedJob->movePoints = 2;
            selectedJob->maxHealth = 3;
            selectedJob->maxRange = 1;
            selectedJob->cost = 6;
            break;

        case 2:
            selectedJob->jobId = 2;
            strcpy(selectedJob->name, "Archer");
            selectedJob->movePoints = 2;
            selectedJob->maxHealth = 2;
            selectedJob->maxRange = 2;
            selectedJob->cost = 6;
            break;
    
        case 3:
            selectedJob->jobId = 3;
            strcpy(selectedJob->name, "Cavalier");
            selectedJob->movePoints = 3;
            selectedJob->maxHealth = 2;
            selectedJob->maxRange = 1;
            selectedJob->cost = 6;
            break;
    
    
        default:
            break;
    }
}

int turn (int turnCounter, GameParameters gameParameters, char playerId, Tile ***map, int *playerWallet, SDL_Renderer* renderer, UIElement **pUiTextureArray, SDL_Texture **mapTextureArray) {
    int income;
    char input = 0;
    char endTurn = 0;
    char isSelectingUnit = 0;
    char isRecruitingUnit = 0;
    char jobId;
    
    Tile selectedTile = {0, 0, 0, NULL, 0, NULL };
    Unit selectedUnit = {playerId, "", 0, 0, 0, NULL };
    Job selectedJob = {1, "", 0, 0, 0, 0};
    changeJobToRecruit(1, &selectedJob);
    jobId = selectedJob.jobId;

    printf("%s", selectedJob.name);



    income = calculateIncome(map, playerId);
    *playerWallet += income;

    while (endTurn == 0) {
        if (input != 1) {   // input 1 is any input not covered , so random input wont refresh the window
            SDL_SetRenderDrawColor(renderer,0,0,0,255);
            SDL_RenderClear(renderer);
            displayMap(gameParameters.mapHeight, gameParameters.mapWidth, *map, renderer, mapTextureArray);
            actualizeUI(renderer, pUiTextureArray, playerId, *playerWallet, income, turnCounter, selectedUnit, selectedJob , isSelectingUnit, isRecruitingUnit);
            displayUI(renderer, gameParameters, pUiTextureArray, isSelectingUnit, isRecruitingUnit);
        }
        input = processInputs(&selectedTile);
        if (input == 0) {           // input 0 is end of turn
            endTurn = 1;
        } else if (input == -1) {   // input -1 is SDL QUIT
            return -1;
        } else if (input == 2) {    // input 2 is save
            return 2;
        } else if (input == 3) {    // input 3 is switch from any mode to recruiting mode
            isSelectingUnit = 0;
            isRecruitingUnit = 1;
        } else if (input == 4 && isRecruitingUnit == 1) {
            jobId--;
            if (jobId <= 0) {
                jobId = 3;
            }
            changeJobToRecruit(jobId, &selectedJob);
        } else if (input == 5 && isRecruitingUnit == 1) {
            jobId++;
            if (jobId >= 4) {
                jobId = 1;
            }
            changeJobToRecruit(jobId, &selectedJob);
        } else if (input == 6 && isRecruitingUnit) {        // input 6 is recruiting
            recruit(selectedJob, map, playerWallet, playerId, gameParameters);
        }
    }

    return 0;
}

void recruit( Job selectedJob, Tile ***pMap, int *pWallet, char playerId, GameParameters parameters ) {
    if (isRecrutingPossible(*pMap, selectedJob, *pWallet, playerId, parameters)) {
        *pWallet -= selectedJob.cost;

    } else {
        printf("\n recrutement impossible!\n");
    }
}

void freeMap (char height, char width, Tile ***map) {
    char i;
    for (i = 0; i < height; i++){
        free((*map)[i]);
    }
    free(*map);
}


// parcoure toutes les unités du joueur, pour les compter, et déduire le salaire
int calculateIncome(Tile ***map, char playerId) {
    return 5;
    // TODO:
}

void displayMap(char mapHeight, char mapWidth, Tile **map, SDL_Renderer *renderer, SDL_Texture **textureArray) {
    int i, j;
    SDL_Rect position;
    for (i = 0 ; i < mapHeight ; i++){
        for (j = 0 ; j < mapWidth ; j++){
            position.x = j * TILE_SIZE;
            position.y = i * TILE_SIZE;
            position.w = TILE_SIZE;
            position.h = TILE_SIZE;

            SDL_RenderCopy(renderer, textureArray[map[i][j].type], NULL, &position);

            // if (map[i][j].type == 2) {
            //     SDL_Surface* loadedSurface = SDL_LoadBMP( "resources/sprites/shield.bmp" );
            //     SDL_Texture *knightTexture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
            //     SDL_RenderCopy(renderer, knightTexture, NULL, &position);

            // }

        }
    }
    SDL_RenderPresent(renderer);
}

void initiateMapTextures( SDL_Renderer *renderer, SDL_Texture ***pMapTextureArray) {
    *pMapTextureArray = malloc(6*sizeof(SDL_Texture*));
    if (*pMapTextureArray != NULL) {

        SDL_Surface *surface;
        surface = SDL_LoadBMP("resources/sprites/void.bmp");
        (*pMapTextureArray)[0] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/blue.bmp");
        (*pMapTextureArray)[1] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/red.bmp");
        (*pMapTextureArray)[2] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/grass1.bmp");
        (*pMapTextureArray)[3] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/wtr.bmp");
        (*pMapTextureArray)[4] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/mnt1.bmp");
        (*pMapTextureArray)[5] = SDL_CreateTextureFromSurface(renderer, surface);
    } else {
        printf("\n malloc in initiate map ERROR");
    }
}

char processInputs(Tile *selectedTile) {
    SDL_Event event;
    char clickingLeft;

    
    SDL_WaitEvent(&event);
    switch(event.type){
        case SDL_QUIT :
            return -1;
        case SDL_MOUSEBUTTONDOWN :
            if (event.button.button == SDL_BUTTON_LEFT) {
                clickingLeft = 1;
            }
            break;
        case SDL_MOUSEBUTTONUP:             
            if (event.button.button == SDL_BUTTON_LEFT){
                clickingLeft = 0;
            }
            break;
        case SDL_KEYDOWN:
            switch(event.key.keysym.sym){
                case SDLK_PAGEUP:
                    return 4;
                case SDLK_PAGEDOWN:
                    return 5;
                case SDLK_r:
                    return 3;
                case SDLK_t:
                    return 0;
                case SDLK_s:
                    return 2;
                case SDLK_RETURN:
                    return 6;
            }
            break;

        default: return 1;
    }
}

void destroyTextures(SDL_Texture ***pMapTextureArray, UIElement **pUiTextureArray) {
    int i;
    printf("\n in free");
    for( i = 0; i < 6; i++)
    {
        if ((*pMapTextureArray)[i] != NULL) {
            SDL_DestroyTexture((*pMapTextureArray)[i]);
        }
    }
    
    free(*pMapTextureArray);

    for( i = 0; i < 12; i++)
    {
        if ((*pUiTextureArray)[i].texture != NULL) {
            SDL_DestroyTexture((*pUiTextureArray)[i].texture);
        }
    }
    free(*pUiTextureArray);
}