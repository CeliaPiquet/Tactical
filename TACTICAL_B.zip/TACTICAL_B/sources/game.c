#include "game.h"

// main game method. starts with map reading and window opening, ends with freeing allocated spaces and destroying window
void game(GameParameters gameParameters, char *mapPath) {
    int imgFlags;
    int error;
    Tile **map;
    int turnCounter = 1;
    char endGame = 0;
    char mapHeight, mapWidth;
    int wallet1, wallet2;
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Rect position;
    SDL_Texture **mapTextureArray;
    UIElement *uiTextureArray;
    ListOfJobs *pListOfJobs;

    TTF_Init();
    imgFlags = IMG_INIT_PNG; 
    if( !( IMG_Init( imgFlags ) & imgFlags ) ) { 
        printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
    }


    error = readMap(mapPath, &map, &gameParameters);


    if (error) {
        printf("\n%s n'est pas valide\n", mapPath);
    } else {
        printf("\n%s valide\n", mapPath);
    }

    window = SDL_CreateWindow("TACTICAL",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, gameParameters.mapWidth * TILE_SIZE + UI_WIDTH, gameParameters.mapHeight * TILE_SIZE + 200, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);

    wallet1 = gameParameters.initialResources1;
    wallet2 = gameParameters.initialResources2;

    pListOfJobs = initiateListOfJobs();


    initiateMapTextures(renderer, &mapTextureArray);


    initiateUI(renderer, &uiTextureArray);

    while ( (turnCounter <= gameParameters.maxTurn || gameParameters.maxTurn == 0) && !endGame ) {
        endGame = turn(turnCounter, gameParameters, 1, &map, &wallet1, renderer, &uiTextureArray, mapTextureArray, *pListOfJobs);
        if(endGame) break;
        endGame = turn(turnCounter, gameParameters, 2, &map, &wallet2, renderer, &uiTextureArray, mapTextureArray, *pListOfJobs);
        if(endGame) break;
        turnCounter++;
        printf("turn : %d\twalletJ_1 : %d\twalletJ_2 : %d\n", turnCounter, wallet1, wallet2);
    }


    // TODO:
    if (endGame == 1) {
        // game has actually ended
    } else if (endGame == 2) {
        // save the game
    } else if (endGame == -1) {
        // just sdl quit with no score nor save
    }


    freeMap(gameParameters.mapHeight, gameParameters.mapWidth, &map);
    freeJobsList(pListOfJobs);

    destroyTextures(&mapTextureArray, &uiTextureArray);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
}

// initializes list of jobs as a circular 2 way linked list, allows us to navigate between pointers of already initialized jobs
ListOfJobs *initiateListOfJobs() {
    ListOfJobs *listOfJobs = malloc(sizeof(ListOfJobs));
    if (listOfJobs != NULL) {
        printf("\n ok malloc list");
        listOfJobs->first = NULL;
        listOfJobs->length = 0;
    }
    Job *warriorJob = malloc(sizeof(Job));
    if (warriorJob !=NULL) {
        warriorJob->jobId = 1;
        warriorJob->cost = 6;
        warriorJob->maxHealth = 3;
        warriorJob->maxRange = 1;
        warriorJob->movePoints = 2;
        strcpy(warriorJob->name, "Guerrier");
        warriorJob->next = NULL;
        warriorJob->prev = NULL;

        listOfJobs->first = warriorJob;
        listOfJobs->length++;
    }
    Job *archerJob = malloc(sizeof(Job));
    if (archerJob !=NULL) {
        archerJob->jobId = 2;
        archerJob->cost = 6;
        archerJob->maxHealth = 2;
        archerJob->maxRange = 2;
        archerJob->movePoints = 2;
        strcpy(archerJob->name, "Archer");


        archerJob->next = NULL;
        archerJob->prev = warriorJob;
        warriorJob->next = archerJob;
        listOfJobs->length++;

    }
    Job *riderJob = malloc(sizeof(Job));
    if (riderJob !=NULL) {
        riderJob->jobId = 3;
        riderJob->cost = 6;
        riderJob->maxHealth = 2;
        riderJob->maxRange = 1;
        riderJob->movePoints = 3;
        strcpy(riderJob->name, "Cavalier");

        riderJob->next = listOfJobs->first;
        riderJob->prev = archerJob;

        archerJob->next = riderJob;
        warriorJob->prev = riderJob;

        listOfJobs->length++;
    }

    if (riderJob!= NULL && archerJob != NULL && warriorJob!= NULL && listOfJobs != NULL) {
        return listOfJobs;
    } else {
        printf("\n error intialize list of job");
    }
}


// check if player HQ is empty and his wallet isnt
char isRecrutingPossible (Tile **map, Job unitToRecruit, int wallet, char playerId, GameParameters parameters) {
    return (isRecruitTileNotOccupied(map, parameters.mapHeight, parameters.mapWidth, playerId) && isRecruitAffordable(unitToRecruit, wallet));
}


// reads map and check if HQ tile Free of unit
char isRecruitTileNotOccupied(Tile **map, int height, int width, char playerId) {
    int i, j;
    
    for( i = 0; i < height; i++) {
        for( j = 0; j < width; j++) {
            if (map[i][j].type == playerId) {
                return (map[i][j].unit == NULL);
            }
        }
    }

    return 0; // shouldnt, map is tested so one tile is equal to player id
}

//checks if player has enough money to buy unit
char isRecruitAffordable(Job unitToRecruit, int wallet) {
    return (wallet - unitToRecruit.cost >= 0);
}

// represents a whole turn of a player
// starts with reseting selections (unit, tile, mode) and units actions. Also follows income
// then listen for inputs and execute actions while the end of turn is not reached
int turn (int turnCounter, GameParameters gameParameters, char playerId, Tile ***map, int *playerWallet, SDL_Renderer* renderer, UIElement **pUiTextureArray, SDL_Texture **mapTextureArray, ListOfJobs listOfJobs) {
    int income;
    char input = 0;
    char endTurn = 0;
    char isSelectingUnit = 0;
    char isRecruitingUnit = 0;
    char jobId;
    int selectedUnitX = -1;
    int selectedUnitY = -1;
    
    Tile selectedTile = {0, 0, 0, 0, 0, 0, 0, 0, NULL };
    Unit selectedUnit = {playerId, 0, 0, 0, NULL };
    Job *pSelectedJob = listOfJobs.first;

    browsePlayerUnits(gameParameters, map, playerId, &income);
    *playerWallet += income;

    while (endTurn == 0) {
        if (input != 1) {   // input 1 is any input not covered , so random input wont refresh the window
            SDL_SetRenderDrawColor(renderer,0,0,0,255);
            SDL_RenderClear(renderer);
            actualizeMap(gameParameters, map, isSelectingUnit);
            displayMap(gameParameters.mapHeight, gameParameters.mapWidth, *map, renderer, mapTextureArray, gameParameters);
            actualizeUI(renderer, pUiTextureArray, playerId, *playerWallet, income, turnCounter, selectedUnit, *pSelectedJob , isSelectingUnit, isRecruitingUnit);
            displayUI(renderer, gameParameters, pUiTextureArray, isSelectingUnit, isRecruitingUnit);
        }
        input = processInputs(&selectedTile, map, gameParameters);
        if (input == 0) {           // input 0 is end of turn
            endTurn = 1;
        } else if (input == -1) {   // input -1 is SDL QUIT
            return -1;
        } else if (input == 2) {    // input 2 is save
            return 2;
        } else if (input == 3) {    // input 3 is switch from any mode to recruiting mode
            isSelectingUnit = 0;
            isRecruitingUnit = 1;
        } else if (input == 4 && isRecruitingUnit == 1) {   // 4 & 5 are recruiting navigation between available jobs
            pSelectedJob = pSelectedJob->prev;
        } else if (input == 5 && isRecruitingUnit == 1) {
            pSelectedJob = pSelectedJob->next;
        } else if (input == 6 && isRecruitingUnit) {        // input 6 is recruiting
            printf("\n%s", pSelectedJob->name);
            recruit(pSelectedJob, map, playerWallet, playerId, gameParameters);
        } else if (input == 7) {                             // input 7 is clicking on tile (selectedTile already updated)
            onClickTile(&selectedTile, map, &selectedUnit, gameParameters, &isSelectingUnit, &isRecruitingUnit, playerId, &selectedUnitX, &selectedUnitY);
        }
    }

    return 0;
}


// called at the beginning of the turn, counts the players for income calculation, and resets their actions
void browsePlayerUnits(GameParameters parameters, Tile ***map, char playerId, int *income) {
    int unitCounter = 0;
    int i, j;
    
    for( i = 0; i < parameters.mapHeight; i++) { 
        for( j = 0; j < parameters.mapWidth; j++) {
            if ((*map)[i][j].unit != NULL) {
                if ((*map)[i][j].unit->owner == playerId) {
                    unitCounter++;
                    resetUnitActions(&((*map)[i][j]));
                }
            } 
        }
    }

    processIncome(unitCounter, income);   
}

// this simulates the upkeep, if the player has more units, he will have less income (the scale is arbitrary (and temporary))
void processIncome(int unitCounter, int *income) {
    if (unitCounter < 5){
        *income = 5;
    } else if (unitCounter < 10) {
        *income = 4;
    } else if (unitCounter < 15) {
        *income = 3;
    } else if (unitCounter < 20) {
        *income = 2;
    } else {
        *income = 1;
    }
}

// restets tiles attributes between each action
void resetTile(Tile *tile, char isSelectingUnit) {
    if (!isSelectingUnit) {
        tile->reachable = 0;
        tile->attackable = 0;
        tile->checked = 0;
        if (tile->unit) {
            if (tile->unit->injuries >= tile->unit->job->maxHealth) {
                free(tile->unit);
                tile->unit = NULL;
            }
        }
    }
}

// reset unit actions
void resetUnitActions(Tile *tile) {
        tile->unit->moved = 0;
        tile->unit->attacked = 0;
}

// browse all map to reset tiles between each action
void actualizeMap(GameParameters parameters, Tile ***map, char isSelectingUnit) {
    int i, j;
    
    for( i = 0; i < parameters.mapHeight; i++) { 
        for( j = 0; j < parameters.mapWidth; j++) {
            resetTile(&((*map)[i][j]), isSelectingUnit);
        }
    }
}

// when user clicks on tile. The outcome depends on
// if he clicks on his own unit, he enters selection mode
// if he is in selection mode and clicks on tile, will try to attack it or reach it, then quit selection mode
void onClickTile(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters, char *pIsSelectingUnit, char *pIsRecruitingUnit, char playerId, int *selectedUnitX, int *selectedUnitY ) {
    if (selectedTile->unit != NULL) {

        if (selectedTile->unit->owner == playerId) {
            *pIsSelectingUnit = 1;
            *pIsRecruitingUnit = 0;
            *selectedUnit = *(selectedTile->unit);
            *selectedUnitX = selectedTile->x;
            *selectedUnitY = selectedTile->y;
            onStartSelectionMode(selectedTile, map, selectedUnit, parameters, playerId);
        } else if (*pIsSelectingUnit == 1) {
            onAttackUnit(selectedUnit, selectedTile, pIsSelectingUnit, map, *selectedUnitX, *selectedUnitY);
        } else {
            printf("\nNothing to do"); 
        }
    } else { 
        if (*pIsSelectingUnit == 1 && selectedTile->reachable) {
            onMoveUnit(selectedUnit, selectedTile, map, selectedUnitX, selectedUnitY);
        }
        *pIsSelectingUnit = 0;
        *pIsRecruitingUnit = 0;
    }
}


// called on recruitment input
// try to pay fornew unit then place it on player HQ
void recruit( Job *selectedJob, Tile ***pMap, int *pWallet, char playerId, GameParameters parameters ) {
    if (isRecrutingPossible(*pMap, *selectedJob, *pWallet, playerId, parameters)) {
        *pWallet -= selectedJob->cost;
        placeNewUnitOnHQ(selectedJob, pMap, playerId, parameters);
    } else {
        printf("\n recrutement impossible!\n");
    }
}

// free dynamic array of tiles (and units inside)
void freeMap (char height, char width, Tile ***map) {
    char i, j;
    for (i = 0; i < height; i++){
        
        for( j = 0; j < width; j++)
        {
            if ((*map)[i][j].unit != NULL) {
                free((*map)[i][j].unit);
            }
        }
        free((*map)[i]);
    }
    free(*map);
}

// process unit job and ownerr id to chose a texture, and render it on the map, on given coordinates
void displayUnitOnTile(SDL_Renderer *renderer, SDL_Rect position, SDL_Texture **textureArray, Unit *unit) {
    int textureIndex = 0;
    if (unit->owner == 1) {
        switch (unit->job->jobId)
        {
            case 1: textureIndex = 6;
                break;
            case 2: textureIndex = 8;
                break;
            case 3: textureIndex = 10;
                break;
            default: break;
        }
    } else if (unit->owner == 2) {
        switch (unit->job->jobId)
        {
            case 1: textureIndex = 7;
                break;
            case 2: textureIndex = 9;
                break;
            case 3: textureIndex = 11;
                break;
            default: break;
        }
    }
    if( textureIndex) {
        SDL_RenderCopy(renderer, textureArray[textureIndex], NULL, &position);
    }
}

// browse map then
// renders a texture for each tile (depending on type)
// renders unit if unit on tile
// renders overlay if tile reachable or attackable
void displayMap(char mapHeight, char mapWidth, Tile **map, SDL_Renderer *renderer, SDL_Texture **textureArray, GameParameters parameters) {
    int i, j;
    SDL_Rect position;

    for (i = 0 ; i < mapHeight ; i++){
        for (j = 0 ; j < mapWidth ; j++){
            position.x = j * TILE_SIZE;
            position.y = i * TILE_SIZE;
            position.w = TILE_SIZE;
            position.h = TILE_SIZE;

            SDL_RenderCopy(renderer, textureArray[map[i][j].type], NULL, &position);

            if (map[i][j].unit != NULL) {
                displayUnitOnTile(renderer, position, textureArray, map[i][j].unit);
            }

            if (map[i][j].reachable && parameters.displayMoveReach) {
                SDL_RenderCopy(renderer, textureArray[12], NULL, &position);                
            }
            if (map[i][j].attackable && parameters.displayAttackReach) {
                SDL_RenderCopy(renderer, textureArray[13], NULL, &position);                
            }
        }
    }
    SDL_RenderPresent(renderer);
}

// free the list of jobs
void freeJobsList(ListOfJobs *listOfJobs) {
    int i;
    if (listOfJobs != NULL) {
        Job *pTemp = listOfJobs->first;
        
        for( i = 0; i < listOfJobs->length; i++) {
            Job *pDel = pTemp;
            pTemp = pDel->next;
            free(pDel);
        }
        free(listOfJobs);
    }
}

// builds a dynamic array of textures for the map, used in the "displayMap" method
void initiateMapTextures( SDL_Renderer *renderer, SDL_Texture ***pMapTextureArray) {
    *pMapTextureArray = malloc(14*sizeof(SDL_Texture*));
    if (*pMapTextureArray != NULL) {

        SDL_Surface *surface;
        surface = SDL_LoadBMP("resources/sprites/void.bmp");
        (*pMapTextureArray)[0] = SDL_CreateTextureFromSurface(renderer, surface);   // 0 to 5 are map tile sprites
        surface = SDL_LoadBMP("resources/sprites/blue.bmp");
        (*pMapTextureArray)[1] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/red.bmp");
        (*pMapTextureArray)[2] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/grass1.bmp");
        (*pMapTextureArray)[3] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/wtr.bmp");
        (*pMapTextureArray)[4] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/mnt1.bmp");
        (*pMapTextureArray)[5] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/blueShield.bmp");
        (*pMapTextureArray)[6] = SDL_CreateTextureFromSurface(renderer, surface);   // 6 to 11 are unit sprites, evens are p1 (blue), odds are p2 (red)
        surface = SDL_LoadBMP("resources/sprites/redShield.bmp");
        (*pMapTextureArray)[7] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/blueBow.bmp");
        (*pMapTextureArray)[8] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/redBow.bmp");
        (*pMapTextureArray)[9] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/blueHorse.bmp");
        (*pMapTextureArray)[10] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/redHorse.bmp");
        (*pMapTextureArray)[11] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/greenOver.bmp");                    // 12 and 13 are semi transparent colored rectangle, for display of reachable and attackable tiles
        (*pMapTextureArray)[12] = SDL_CreateTextureFromSurface(renderer, surface);
        surface = SDL_LoadBMP("resources/sprites/redOver.bmp");
        (*pMapTextureArray)[13] = SDL_CreateTextureFromSurface(renderer, surface);
    } else {
        printf("\n malloc in initiate map ERROR");
    }
}

// checks if the click is inside map
char isInsideMap (SDL_Event event, GameParameters parameters) {
    if (event.button.x > 0 && event.button.x < parameters.mapWidth * TILE_SIZE && event.button.y > 0 && event.button.y < parameters.mapHeight * TILE_SIZE ) {
        return 1;
    } else {
        return 0;
    }
}

// this method filters inputs
// each unwanted input will return 1, so the window won't refresh in the "turn" function
// set  coordonates if user clicks on map
char processInputs(Tile *selectedTile, Tile ***map, GameParameters parameters) {
    SDL_Event event;
    char clickingLeft;
    int tileX, tileY;

    
    SDL_WaitEvent(&event);
    switch(event.type){
        case SDL_QUIT :
            return -1;
        case SDL_MOUSEBUTTONDOWN :
            if (event.button.button == SDL_BUTTON_LEFT) {
                clickingLeft = 1;
                if (isInsideMap(event, parameters)) {
                    tileX = event.button.x / TILE_SIZE;
                    tileY = event.button.y / TILE_SIZE;
                    tileX = event.button.x / TILE_SIZE;
                    *selectedTile = (*map)[tileY][tileX];
                    return 7;
                } else {
                    printf("\n i\noutside map");
                    return 1;
                }
            }
            break;
        case SDL_MOUSEBUTTONUP:             
            if (event.button.button == SDL_BUTTON_LEFT){
                clickingLeft = 0;
                return 1;
            }
            break;
        case SDL_KEYDOWN:
            switch(event.key.keysym.sym){
                case SDLK_PAGEUP:
                    return 4;
                case SDLK_PAGEDOWN:
                    return 5;
                case SDLK_r:
                    return 3;
                case SDLK_t:
                    return 0;
                case SDLK_s:
                    return 2;
                case SDLK_RETURN:
                    return 6;
            }
            break;

        default: return 1;
    }
}

// free both dynamic arrays of textures
void destroyTextures(SDL_Texture ***pMapTextureArray, UIElement **pUiTextureArray) {
    int i;
    printf("\n in free");
    for( i = 0; i < 14; i++)
    {
        if ((*pMapTextureArray)[i] != NULL) {
            SDL_DestroyTexture((*pMapTextureArray)[i]);
        }
    }
    free(*pMapTextureArray);

    for( i = 0; i < 12; i++)
    {
        if ((*pUiTextureArray)[i].texture != NULL) {
            SDL_DestroyTexture((*pUiTextureArray)[i].texture);
        }
    }
    free(*pUiTextureArray);
}
