
#include "game.h"

#define CONF_PATH "resources/game.cfg"

// returns the definitive parameter structure
void setGameParameters(GameParameters* gameParameters) {

    GameParameters *customConfigParameters = NULL;
    
    FILE * confFile = fopen(CONF_PATH, "r");
    if (confFile != NULL) {
        printf("opened conffile\n");
        customConfigParameters = readConfigFile(confFile);
        if (fclose(confFile)) {
            printf("conffile read and closed\n");
            // conf file closed succesfully
        } else {
            // could not close config file
        }
        
    } else {
        // could not open config file
    }

    if (areGameConfigValid(*customConfigParameters)) {
        printf("\n custom config ok\n");
        gameParameters->maxTurn = customConfigParameters->maxTurn;
        gameParameters->initialResources1 = customConfigParameters->initialResources1;
        gameParameters->initialResources2 = customConfigParameters->initialResources2;
        gameParameters->displayMoveReach = customConfigParameters->displayMoveReach;
        gameParameters->displayAttackReach = customConfigParameters->displayAttackReach;
        gameParameters->spritesFolderPath = customConfigParameters->spritesFolderPath;
        gameParameters->isDefault = 0;

        free(customConfigParameters);

        
    } else {
        // TODO: display "corrupt config file, set config to default" 

    }
}

// tests the validity of the custom parameters
int areGameConfigValid(GameParameters configParameters) { // TODO:

    
    if (configParameters.maxTurn < 0) {
        printf("config no ok\n");
        return 0;
    } else if (configParameters.initialResources1 < 0) {
        printf("config no ok\n");
        return 0;
    } else if (configParameters.initialResources2 < 0) {
        printf("config no ok\n");
        return 0;
    } else if (configParameters.displayMoveReach != 0 && configParameters.displayMoveReach != 1 ) {
        printf("config no ok\n");
        return 0;
    } else if (configParameters.displayAttackReach != 0 && configParameters.displayAttackReach != 1 ) {
        printf("config no ok\n");
        return 0;
    } else if (!isSpritesFolderValid(configParameters.spritesFolderPath)) {
        printf("foldir no ok\n");
        return 0;
    } 
    return 1;
}


int isSpritesFolderValid (char * folderName ) {

    DIR* dir = opendir(folderName);
    if (dir) {  // folder exists
        closedir(dir);
        return 1;
    } else {
        return 0;
    }
}


GameParameters* readConfigFile(FILE* file) {
    
    char singleLine[255];



    GameParameters* pTemporaryParameters = malloc(sizeof(GameParameters));
    pTemporaryParameters -> spritesFolderPath = malloc(sizeof(char) * 256);
    pTemporaryParameters -> displayMoveReach = 0;
    pTemporaryParameters -> displayAttackReach = 0;

    

    while (fgets(singleLine, 255, file)) {
        processLine(singleLine, 255, pTemporaryParameters);
    }

    return pTemporaryParameters;
}

void displayParameters(GameParameters *p) { //DEBUG
    printf("Parameter : [ maxturn : %d; mapHeight : %d: mapWidth : %d; initResource 1 : %d; initResource 2 : %d; moveReach : %d; attackReach : %d; spritesFolder : %s ]\n", 
                    p->maxTurn, p->mapHeight, p->mapWidth, p->initialResources1, p->initialResources2, p->displayMoveReach, p->displayAttackReach, p->spritesFolderPath);
}

void processLine(char* line, int size, GameParameters* pParameters) {

    if (line[0] == '#' || strlen(line) == 0 || line[0] == '\n') {
        return;
    } else {
        parseLine(line, pParameters);
    }
}

// looks for parameter cue and calls for process method according to type
void parseLine(char* line, GameParameters* pParameters) {

    if (line[strlen(line)-1] == '\n'){
        line[strlen(line)-1] = '\0';
    }

    
    if (strstr(line, "MAX_TURN")){
        pParameters -> maxTurn = processIntegerParameterLine(line);

    } else if (strstr(line, "PLAYER_1_INITIAL_RESOURCES")) {
        pParameters -> initialResources1 = processIntegerParameterLine(line);

    } else if (strstr(line, "PLAYER_2_INITIAL_RESOURCES")) {
        pParameters -> initialResources2 = processIntegerParameterLine(line);

    } else if (strstr(line, "DISPLAY_MOVE_REACH")) {
        pParameters -> displayMoveReach = 1;

    } else if (strstr(line, "DISPLAY_ATTACK_REACH")) {
        pParameters -> displayAttackReach = 1;

    } else if (strstr(line, "SPRITES_PATH")) {
        strcpy(pParameters->spritesFolderPath, processStringParameterLine(line));
    }
}

// returns the integer value after = symbol
char processIntegerParameterLine(char * line) {
    int equalPos = strchr(line, '=') - line;
    return atoi(line + equalPos + 1);
}


// returns the decimal value after = symbol
double processDecimalParameterLine(char * line) {
    int equalPos = strchr(line, '=') - line;
    return atof(line + equalPos + 1);
}


// returns the string value after = symbol
char * processStringParameterLine(char * line) {
    int equalPos = strchr(line, '=') - line;
    return (line + equalPos + 1);
}