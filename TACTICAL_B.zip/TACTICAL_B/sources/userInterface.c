#include "game.h"


void initiateUI(SDL_Renderer *renderer, UIElement **uiTextureArray) {
    TTF_Font *font;
    SDL_Surface *textMessage;
    SDL_Color white = {255, 255, 255};

    *uiTextureArray = malloc(12 * sizeof(UIElement));
    if (*uiTextureArray != NULL) {

    } else {
        printf("\n malloc in initiate ui ERROR");
    }
    font = TTF_OpenFont("resources/font/cour.ttf", 18);

    textMessage = TTF_RenderText_Solid(font, "Tactical", white);
    (*uiTextureArray)[0].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 0 is title
    (*uiTextureArray)[0].h = textMessage->h;
    (*uiTextureArray)[0].w = textMessage->w;

    font = TTF_OpenFont("resources/font/cour.ttf", 14);
   
    textMessage = TTF_RenderText_Solid(font, "T: passer le tour", white);
    (*uiTextureArray)[1].texture = SDL_CreateTextureFromSurface(renderer, textMessage);     // 1 to 2 is commands help
    (*uiTextureArray)[1].h = textMessage->h;
    (*uiTextureArray)[1].w = textMessage->w;

    textMessage = TTF_RenderText_Solid(font, "S: sauvegarder", white);
    (*uiTextureArray)[2].texture = SDL_CreateTextureFromSurface(renderer, textMessage);
    (*uiTextureArray)[2].h = textMessage->h;
    (*uiTextureArray)[2].w = textMessage->w;

    
}

void setPosition(SDL_Rect *pPosition, int x, int y, int h, int w) {
    pPosition->x = x;
    pPosition->y = y;
    pPosition->h = h;
    pPosition->w = w;
}

void setUITextureToPosition(SDL_Renderer *renderer, UIElement uiElement, int x, int y) {
    SDL_Rect position;
    setPosition(&position, x, y, uiElement.h, uiElement.w );
    SDL_RenderCopy(renderer, uiElement.texture, NULL, &position);
}

void displayUI(SDL_Renderer *renderer, GameParameters gameParameters, UIElement **uiTextureArray, char isSelectingUnit, char isRecruitingUnit) {
    int x, y;
    x = gameParameters.mapWidth * TILE_SIZE + 30;
    y = 10;
    setUITextureToPosition(renderer, (*uiTextureArray)[0], x, y );
    x = gameParameters.mapWidth * TILE_SIZE +10;
    y += (*uiTextureArray)[0].h;
    setUITextureToPosition(renderer, (*uiTextureArray)[1], x, y );
    y += (*uiTextureArray)[1].h;
    setUITextureToPosition(renderer, (*uiTextureArray)[2], x, y );
    y += (*uiTextureArray)[2].h;
    setUITextureToPosition(renderer, (*uiTextureArray)[10], x, y );
    x += (*uiTextureArray)[10].w;
    setUITextureToPosition(renderer, (*uiTextureArray)[9], x, y );
    x = gameParameters.mapWidth * TILE_SIZE +10;
    y += (*uiTextureArray)[9].h;
    setUITextureToPosition(renderer, (*uiTextureArray)[11], x, y );
    y += (*uiTextureArray)[11].h + 10;
    x += 20;
    setUITextureToPosition(renderer, (*uiTextureArray)[3], x, y );
    x = gameParameters.mapWidth * TILE_SIZE +10;
    y += (*uiTextureArray)[3].h;
    if (isRecruitingUnit) {
        setUITextureToPosition(renderer, (*uiTextureArray)[5], x, y );
        y += (*uiTextureArray)[5].h;
        setUITextureToPosition(renderer, (*uiTextureArray)[6], x, y );
        y += (*uiTextureArray)[6].h;
        setUITextureToPosition(renderer, (*uiTextureArray)[7], x, y );
        y += (*uiTextureArray)[7].h;
        setUITextureToPosition(renderer, (*uiTextureArray)[8], x, y );
    } else if (isSelectingUnit) {
        setUITextureToPosition(renderer, (*uiTextureArray)[4], x, y );
    }

    // setPosition(&position, gameParameters.mapWidth * TILE_SIZE + 10, 10, (*uiTextureArray)[0].h, (*uiTextureArray)[0].w );
    // SDL_RenderCopy(renderer, (*uiTextureArray)[0].texture, NULL, &position);
    // setPosition(&position, gameParameters.mapWidth * TILE_SIZE + 10, 40, (*uiTextureArray)[1].h, (*uiTextureArray)[1].w );
    // SDL_RenderCopy(renderer, (*uiTextureArray)[1].texture, NULL, &position);
    // setPosition(&position, gameParameters.mapWidth * TILE_SIZE + 10, 64, 24, 200 );
    // SDL_RenderCopy(renderer, (*uiTextureArray)[2].texture, NULL, &position);
    SDL_RenderPresent(renderer);
}


// uiTextureArray is initialized, and its 4 first slots are constant, we only update the following depending on the game state, and inputs
void actualizeUI(SDL_Renderer *renderer, UIElement **uiTextureArray, char playerId, int wallet, int income, int turn, Unit selectedUnit, Job unitToRecruit, char selecting, char recruiting) {
    TTF_Font *font;
    SDL_Surface *textMessage;
    SDL_Color white = {255, 255, 255};
    SDL_Color red = {255, 100, 100};
    SDL_Color blue = {100, 100, 255};
    char message[255];

    // printf("\n in actualize UI\t");
    // printf("%s - HP: %d MP: %d Portee: %d ", unitToRecruit.name, unitToRecruit.maxHealth, unitToRecruit.movePoints, unitToRecruit.maxRange);

    

    font = TTF_OpenFont("resources/font/cour.ttf", 13);

    if (selecting) {
        printf("%s - HP: %d MP: %d Portee: %d ", selectedUnit.job->name, selectedUnit.job->maxHealth, selectedUnit.job->movePoints, selectedUnit.job->maxRange);
        
        textMessage = TTF_RenderText_Solid(font, "Selection", white);
        (*uiTextureArray)[3].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 3 is mode
        (*uiTextureArray)[3].h = textMessage->h;
        (*uiTextureArray)[3].w = textMessage->w;

        sprintf(message, "%s HP: %d MP: %d AP: %d", 
        selectedUnit.job->name, 
        selectedUnit.job->maxHealth - selectedUnit.injuries,
        selectedUnit.moved? selectedUnit.job->movePoints : 0,
        selectedUnit.attacked? 0 : 1 );
        textMessage = TTF_RenderText_Blended(font, message, white);
        (*uiTextureArray)[4].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 4 is selected unit
        (*uiTextureArray)[4].h = textMessage->h;
        (*uiTextureArray)[4].w = textMessage->w;
    } else {
        (*uiTextureArray)[4].texture = NULL;
    }

    if (recruiting) {

        textMessage = TTF_RenderText_Solid(font, "Recrutement", white);
        (*uiTextureArray)[3].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 3 is mode
        (*uiTextureArray)[3].h = textMessage->h;
        (*uiTextureArray)[3].w = textMessage->w;

        sprintf(message, "%s - HP: %d MP: %d Portee: %d ", 
        unitToRecruit.name,
        unitToRecruit.maxHealth,
        unitToRecruit.movePoints,
        unitToRecruit.maxRange);
        textMessage = TTF_RenderText_Solid(font, message, white);
        (*uiTextureArray)[5].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 5 is unit to recruit
        (*uiTextureArray)[5].h = textMessage->h;
        (*uiTextureArray)[5].w = textMessage->w;


        sprintf(message, "prix: %d (%d)", 
        unitToRecruit.cost,
        wallet);
        textMessage = TTF_RenderText_Solid(font, message, white);
        (*uiTextureArray)[6].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 6 is unit to recruit cost
        (*uiTextureArray)[6].h = textMessage->h;
        (*uiTextureArray)[6].w = textMessage->w;

        sprintf(message, "Entrer pour valider");
        textMessage = TTF_RenderText_Solid(font, message, white);
        (*uiTextureArray)[7].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 7 is validate
        (*uiTextureArray)[7].h = textMessage->h;
        (*uiTextureArray)[7].w = textMessage->w;

        sprintf(message, "changer: gauche et droite");
        textMessage = TTF_RenderText_Solid(font, message, white);
        (*uiTextureArray)[8].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 8 is change unit to recruit
        (*uiTextureArray)[8].h = textMessage->h;
        (*uiTextureArray)[8].w = textMessage->w;
    } else {
        (*uiTextureArray)[5].texture = NULL;
        (*uiTextureArray)[6].texture = NULL;
        (*uiTextureArray)[7].texture = NULL;
        (*uiTextureArray)[8].texture = NULL;
    }

    if (!recruiting && !selecting) {
        textMessage = TTF_RenderText_Solid(font, "R: recruter", white);
        (*uiTextureArray)[3].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // idle mode
        (*uiTextureArray)[3].h = textMessage->h;
        (*uiTextureArray)[3].w = textMessage->w;
    }

    font = TTF_OpenFont("resources/font/cour.ttf", 18);

    sprintf(message, " - TOUR %d", turn);
    textMessage = TTF_RenderText_Solid(font, message, white);
    (*uiTextureArray)[9].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 9 is turn counter
    (*uiTextureArray)[9].h = textMessage->h;
    (*uiTextureArray)[9].w = textMessage->w;
    

    sprintf(message, "Joueur %d", playerId);
    if (playerId == 1) {
        textMessage = TTF_RenderText_Solid(font, message, blue);
    } else {
        textMessage = TTF_RenderText_Solid(font, message, red);
    }
    (*uiTextureArray)[10].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 10 is player id
    (*uiTextureArray)[10].h = textMessage->h;
    (*uiTextureArray)[10].w = textMessage->w;

    font = TTF_OpenFont("resources/font/cour.ttf", 18);

    sprintf(message, "Ressource: %d (+%d)", wallet, income);
    textMessage = TTF_RenderText_Solid(font, message, white);
    (*uiTextureArray)[11].texture = SDL_CreateTextureFromSurface(renderer, textMessage); // 11 iswallet and income
    (*uiTextureArray)[11].h = textMessage->h;
    (*uiTextureArray)[11].w = textMessage->w;
}
