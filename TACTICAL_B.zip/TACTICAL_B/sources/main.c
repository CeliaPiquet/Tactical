
#include "game.h"

int main(int argc, char const *argv[])
{   
    int choice;
    char *mapPath = "resources/maps/mapMock";
    // default values for game parameters
    // GameParameters gameParameters = {50, 5, 5, 1, 1, "../resources/sprites", 1} ;

    //test purposes
    GameParameters gameParameters = {33, 5, 5, 0, 0, 0, 0, 3, 3, 1, 1, "resources/sprites", 1} ;

    setGameParameters(&gameParameters);

    // test
    displayParameters(&gameParameters);

    // choice = menu();

    game(gameParameters, mapPath);

    free(gameParameters.spritesFolderPath);


    return 0;
}
