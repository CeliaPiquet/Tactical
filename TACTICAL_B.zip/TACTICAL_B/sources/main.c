#include "game.h"

int main(int argc, char const *argv[])
{   
    int choice;
    char *mapPath;
    // default values for game parameters
    // GameParameters gameParameters = {50, 5, 5, 1, 1, "../resources/sprites", 1} ;

    //test purposes
    GameParameters gameParameters = {33, 3, 3, 1, 1, "resources/sprites", 1} ;
    mapPath = "resources/maps/mapMock";

    setGameParameters(&gameParameters);

    displayParameters(&gameParameters);

    // choice = menu();

    game(gameParameters, mapPath);

    free(gameParameters.spritesFolderPath);


    return 0;
}
