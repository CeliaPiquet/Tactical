#include "game.h"

int menu() {
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Event event;
    int toContinue = 1;
    if (SDL_Init(SDL_INIT_VIDEO) != 0){
        fprintf(stdout,"Echec : %s \n", SDL_GetError());
    }

    window = SDL_CreateWindow("TACTICAL",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, SDL_WINDOW_SHOWN);

    if (window){
        renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED); // Création d'un SDL_Renderer utilisant l'accélération matérielle
        // editor(window);
        while (toContinue) {

            if (renderer == NULL) {
                renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);
            }

            
            

            displayMenuBackground(window, renderer);
            displayMenuOptions(window, renderer);
            SDL_RenderPresent(renderer); // Affichage

            SDL_WaitEvent(&event);

            
            switch (event.type)
            {
                case SDL_QUIT:
                    toContinue = 0;
                    break;

                case SDL_MOUSEBUTTONDOWN:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        printf("\n\n x: %d\t y : %d", event.button.x, event.button.y);
                        if (event.button.x > 310 && event.button.x < 490 && event.button.y > 200 && event.button.y < 240){
                            mapMenu(window, renderer);
                        } else if (event.button.x > 305 && event.button.x < 500 && event.button.y > 280 && event.button.y < 320){
                            printf("\nsecond bouton");
                        } else if (event.button.x > 345 && event.button.x < 560 && event.button.y > 360 && event.button.y < 400){
                            toContinue = 0;
                        }
                    }
            
                default:
                    break;
            }
        }
        SDL_DestroyWindow(window);
    }



    else {
        fprintf(stderr,"Erreur création fenêtre : %s \n", SDL_GetError());
    }

    SDL_Quit();

    return 1;
}

void displayMenuBackground(SDL_Window* pWindow, SDL_Renderer* renderer) {

    SDL_SetRenderDrawColor(renderer, 0, 139, 139, 255);

    // Clear the entire screen to our selected color.
    SDL_RenderClear(renderer);
    
}

void displayMenuOptions(SDL_Window* pWindow, SDL_Renderer* renderer) {
    

    // SDL_SetRenderDrawColor( renderer, 0, 139, 139, 255);
   
    if ( renderer )
    {
        insertButtonIntoMenu("resources/sprites/UI_sprites/button_1_player.bmp", -80, renderer);
        insertButtonIntoMenu("resources/sprites/UI_sprites/button_2_players.bmp", 0, renderer);
        insertButtonIntoMenu("resources/sprites/UI_sprites/button_quitter.bmp", 80, renderer);
        
    }
    else
    {
        fprintf(stdout,"Échec de création du renderer (%s)\n",SDL_GetError());
    }
}

void insertButtonIntoMenu(char* buttonSpritePath, int verticalOffset, SDL_Renderer* renderer) {
    SDL_Surface* pSprite = NULL;
    SDL_Texture* pTexture = NULL;
    pSprite = SDL_LoadBMP(buttonSpritePath);
    if ( pSprite )
    {
        pTexture = SDL_CreateTextureFromSurface(renderer,pSprite); // Préparation du sprite
        if ( pTexture )
        {
            SDL_Rect dest = { 800/2 - pSprite->w/2, 600/2 - pSprite->h/2 + verticalOffset, pSprite->w, pSprite->h};
            SDL_RenderCopy(renderer,pTexture,NULL,&dest); // Copie du sprite grâce au SDL_Renderer


            SDL_DestroyTexture(pTexture); // Libération de la mémoire associée à la texture
        }
        else
        {
            fprintf(stdout,"Échec de création de la texture (%s)\n",SDL_GetError());
        }

        SDL_FreeSurface(pSprite); // Libération de la ressource occupée par le sprite
    }
    else
    {
        fprintf(stdout,"Échec de chargement du sprite (%s)\n",SDL_GetError());
    }
}



void mapMenu(SDL_Window* window, SDL_Renderer* renderer) {
    // SDL_DestroyRenderer(renderer);
    // if (renderer == NULL) {
    //     renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);
    //     SDL_DestroyRenderer(renderer);
    // }
}