#include "game.h"

/*
    RAPPEL types:
    0 = void
    1 = QG joueur 1 (bleu)
    2 = QG joueur 2 (rouge)
    3 = grass
    4 = water
    5 = mountain
*/


int readMap(char *mapPath, Tile ***pMap, GameParameters *parameters ) {
    char code;

    FILE *fileMap;

    fileMap = fopen(mapPath, "rb");
    if (fileMap) {
        code = fread(&(parameters->mapHeight), sizeof(char), 1, fileMap);
        if (!code) {
            return 1;
        }
        code = fread(&(parameters->mapWidth), sizeof(char), 1, fileMap);
        if (!code) {
            return 1;
        }

        displayParameters(parameters);


        inititializeMapArray(fileMap, pMap, parameters);
        fclose(fileMap);
        printf("\n in readmap\n");
        readMapArray(*pMap, parameters->mapHeight, parameters->mapWidth);

        return 0;
    } else {
        return 1;
    }
}

void inititializeMapArray(FILE *fileMap, Tile ***pMap, GameParameters *parameters ) {
    char i, j;
    char code;
    char error = 0;


    *pMap = malloc(sizeof(Tile*) * parameters->mapHeight);

    if ( *pMap == NULL) {
        printf("\nprobleme allocation mémoire pour le tableau entier");
    } else {
        for( i = 0; i < parameters->mapHeight; i++) {
            (*pMap)[i] = malloc (sizeof(Tile) * parameters->mapWidth);
            if ((*pMap)[i] == NULL) {
                printf("\nerror initialize map array 1");
            } else {
                
                for( j = 0; j < parameters->mapWidth; j++)
                {
                    code = fread(&((*pMap)[i][j].type), sizeof(char), 1, fileMap); 
                    if (!code) {
                        error = 1;   
                    } else {
                        (*pMap)[i][j].x = j;
                        (*pMap)[i][j].y = i;
                        (*pMap)[i][j].unit = NULL;
                        if ((*pMap)[i][j].type == 1) {
                            parameters->QG1x = j;
                            parameters->QG1y = i;
                        }

                        if ((*pMap)[i][j].type == 2) {
                            parameters->QG2x = j;
                            parameters->QG2y = i;
                        }

                        if ((*pMap)[i][j].type == 0 || (*pMap)[i][j].type == 4 ) {
                            (*pMap)[i][j].moveCost = -1;
                        } else if ((*pMap)[i][j].type == 5) {
                            (*pMap)[i][j].moveCost = 2;
                        } else {
                            (*pMap)[i][j].moveCost = 1;
                        }
                    }
                }
            }
        }

        if (error) {
            printf ("\nprobleme lecture map\n");
        }  

    }

}


// for debug
void readMapArray(Tile **map, char height, char width ) {
    int i, j;

    printf("\n in readmap array\n");
    
    for( i = 0; i < height; i++)
    {
        for( j = 0; j < width; j++)
        {
            printf("%d ", map[i][j].type);
        }

        printf("\n");
    }
}