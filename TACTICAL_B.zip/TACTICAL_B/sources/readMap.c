#include "game.h"


int readMap(char *mapPath, char ***pMap) {
    char height, width;
    char code;
    int i;

    FILE *fileMap;

    fileMap = fopen(mapPath, "rb");
    if (fileMap) {
        code = fread(&height, sizeof(char), 1, fileMap);
        if (!code) {
            return 1;
        }
        code = fread(&width, sizeof(char), 1, fileMap);
        if (!code) {
            return 1;
        }


        printf("h: %d , w: %d\n", height, width);



        inititializeSimpleMapArray(fileMap, pMap, height, width);
        fclose(fileMap);
        readMapArray(pMap, height, width );

        for (i = 0; i < height; i++){
            free((*pMap)[i]);
        }
        free(*pMap);

        return 0;
    } else {
        return 1;
    }
}

void inititializeSimpleMapArray(FILE *fileMap, char ***pMap, char height, char width ) {
    char i, j;
    char code;
    char error = 0;

    printf("\nin initialize map");


    *pMap = malloc(sizeof(char*) * height);

    if ( *pMap == NULL) {
        printf("\nprobleme allocation mémoire pour le tableau entier");
    } else {
        printf("\nok");
        for( i = 0; i < height; i++) {
            (*pMap)[i] = malloc (sizeof(char) * width);
            code = fread((*pMap)[i], sizeof(char), width, fileMap); 
            if (code != width)  error = 1;
        }

        if (error) {
            printf ("\nprobleme lecture map\n");
        }  

    }
    
    // *pMap = malloc( height * sizeof(char*));

    // printf("\nmalloc 1 ok?");
    // if (*pMap != NULL) {
    //     printf("\nmalloc 1 ok");

    //     for( i = 0; i < height; i++) {
    //         code = fread((*pMap)[i], sizeof(char), width, fileMap); 
    //         if (code != width)  error = 1;
    //     }

    //     if (error) {
    //         printf ("\nprobleme lecture map\n");
    //     }
    // } else {
    //     printf("\nmalloc 1 nul");
    // }
    

}

void readMapArray(char ***pMap, char height, char width ) {
    int i, j;

    printf("\nin readmaparray");


    printf("\n");
    
    for( i = 0; i < height; i++)
    {
        for( j = 0; j < width; j++)
        {
            printf("%d ", (*pMap)[i][j]);
        }

        printf("\n");
        
    }
    
}