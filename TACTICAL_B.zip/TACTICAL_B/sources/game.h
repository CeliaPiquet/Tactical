
#ifndef PROJECT_TRY

#define PROJECT_TRY

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

#include <SDL2/SDL.h>

// region stuctures

typedef struct GameParameters GameParameters;
struct GameParameters
{
    int maxTurn;
    char initialResources1;
    char initialResources2;
    char displayMoveReach;
    char displayAttackReach;
    char* spritesFolderPath;
    char isDefault;
};


//region configuration

void setGameParameters(GameParameters*);

int areGameConfigValid(GameParameters configParameters);

int areMapDimensionsValid(char mapHeight, char mapWidth);

int isSpritesFolderValid (char *folderName );

GameParameters* readConfigFile(FILE* config);

void processLine(char* line, int, GameParameters*);

void parseLine(char*, GameParameters*);

char processIntegerParameterLine(char * line);


double processDecimalParameterLine(char * line);

char * processStringParameterLine(char * line);

void displayParameters(GameParameters *parameters);


// region menu

int menu();

void displayMenuBackground(SDL_Window* pWindow, SDL_Renderer* renderer);
void displayMenuOptions(SDL_Window* pWindow, SDL_Renderer* renderer);

void insertButtonIntoMenu(char* buttonSpritePath, int verticalOffset, SDL_Renderer* renderer);

void mapMenu(SDL_Window* window, SDL_Renderer* renderer);


// region game

void game(GameParameters gameParameters, char *mapPath);

// region map

int readMap(char *mapPath, char ***pMap);

void inititializeSimpleMapArray(FILE *fmap, char ***pMap, char height, char width );

void readMapArray(char ***pMap, char height, char width );

#endif