
#ifndef PROJECT_TRY

#define PROJECT_TRY

#define TILE_SIZE 32
#define UI_WIDTH 300



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>


#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

// region stuctures

typedef struct UIElement UIElement;
struct UIElement
{
    SDL_Texture *texture;
    int h;
    int w;
};

typedef struct GameParameters GameParameters;
struct GameParameters
{
    int maxTurn;
    int mapHeight;
    int mapWidth;
    int QG1x;
    int QG1y;
    int QG2x;
    int QG2y;
    char initialResources1;
    char initialResources2;
    char displayMoveReach;
    char displayAttackReach;
    char *spritesFolderPath;
    char isDefault;
};

typedef struct Job Job;
struct Job
{
    char jobId;
    char name[200];
    char movePoints;
    char maxHealth;
    char maxRange;
    char cost;
    Job *prev;
    Job *next;
};

typedef struct Unit Unit;
struct Unit
{
    char owner;
    char injuries;
    char moved;
    char attacked;
    Job *job;
};

typedef struct Tile Tile;
struct Tile
{
    int x;
    int y;
    char type;
    char moveCost;
    int totalMoveCost;
    char checked;
    char reachable;
    char attackable;
    Unit *unit;
};

typedef struct ListOfJobs ListOfJobs;
struct ListOfJobs
{
    int length;
    Job *first;
};


//region configuration

void setGameParameters(GameParameters*);

int areGameConfigValid(GameParameters configParameters);

int areMapDimensionsValid(char mapHeight, char mapWidth);

int isSpritesFolderValid (char *folderName );

GameParameters* readConfigFile(FILE* config);

void processLine(char* line, int, GameParameters*);

void parseLine(char*, GameParameters*);

char processIntegerParameterLine(char * line);


double processDecimalParameterLine(char * line);

char * processStringParameterLine(char * line);

void displayParameters(GameParameters *parameters);


// region menu

int menu();

void displayMenuBackground(SDL_Window* pWindow, SDL_Renderer* renderer);
void displayMenuOptions(SDL_Window* pWindow, SDL_Renderer* renderer);
void insertButtonIntoMenu(char* buttonSpritePath, int verticalOffset, SDL_Renderer* renderer);
void mapMenu(SDL_Window* window, SDL_Renderer* renderer);


// region game

ListOfJobs *initiateListOfJobs();

void game(GameParameters gameParameters, char *mapPath);

int turn (int turnCounter, GameParameters gameParameters, char playerId, Tile ***map, int *playerWallet, SDL_Renderer* renderer, UIElement **pUiTextureArray, SDL_Texture **mapTextureArray, ListOfJobs listOfJobs);

void freeMap (char height, char width, Tile ***map);

void freeJobsList(ListOfJobs *listOfJobs);

void processIncome(int unitCounter, int *income);

void resetUnitsActions(GameParameters parameters, Tile ***map);

void actualizeMap(GameParameters parameters, Tile ***map, char isSelectingUnit);


void displayMap(char mapHeight, char mapWidth, Tile **map, SDL_Renderer *renderer, SDL_Texture **textureArray, GameParameters parameters);

void initiateMapTextures( SDL_Renderer *renderer, SDL_Texture ***mapTextureArray);

void resetTile(Tile *tile, char isSelectingUnit);

void resetUnitActions(Tile *tile);

void browsePlayerUnits(GameParameters parameters, Tile ***map, char playerId, int *income);

char processInputs(Tile *selectedTile, Tile ***map, GameParameters parameters);

void onClickTile(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters,  char *pIsSelectingUnit, char *pIsRecruitingUnit, char playerId , int *selectedUnitX, int* selectedUnitY  );




void destroyTextures(SDL_Texture ***pMapTextureArray, UIElement **pUiTextureArray);

void recruit( Job *selectedJob, Tile ***map, int *pWallet, char playerId, GameParameters parameters );

char isRecrutingPossible (Tile **map, Job unitToRecruit, int wallet, char playerId, GameParameters parameters);
char isRecruitTileNotOccupied(Tile **map, int height, int width, char playerId);
char isRecruitAffordable(Job unitToRecruit, int wallet);

void displayUnitOnTile(SDL_Renderer *renderer, SDL_Rect position, SDL_Texture **textureArray, Unit *unit);



// region unit manipulation

void placeNewUnitOnHQ(Job *selectedJob, Tile ***pMap, char playerId, GameParameters parameters);

void onMoveUnit(Unit *selectedUnit, Tile *selectedTile, Tile ***map, int *selectedUnitX, int *selectedUnitY);

void destroyUnit(Tile *selectedTile, Tile ***map);

void onAttackUnit(Unit *selectedUnit, Tile *selectedTile, char *pIsSelectingUnit, Tile ***map , int selectedUnitX, int selectedUnitY);

void onStartSelectionMode(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters, char playerId);

void resetAllTotalMoveCosts(Tile *selectedTile, Tile ***map, GameParameters parameters);

void setAllTotalMoveCosts(Tile ***map, GameParameters parameters);

char findMinimumCostTile(int *minX, int *minY, Tile **map,GameParameters parameters);

void setNeighborTilesCosts(int minX, int minY, Tile ***map, GameParameters parameters);

void setSingleNeighborTileCost(int cost, int x, int y, Tile ***map, GameParameters parameters);

char isTileAccessible(int x, int y, Tile **map, GameParameters parameters);

void displayAllTotalMoveCosts(Tile **map, GameParameters parameters);

void findAllReachableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters);

void processReachableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters);

void processAttackableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters);


// region UI


void initiateUI(SDL_Renderer *renderer,UIElement **uiTextureArray);

void displayUI(SDL_Renderer *renderer, GameParameters gameParameters, UIElement **uiTextureArray, char isSelectingUnit, char isRecruitingUnit);

void actualizeUI(SDL_Renderer *renderer, UIElement **uiTextureArray, char playerId, int wallet, int income, int turn, Unit selectedUnit, Job unitToRecruit, char recruiting, char selecting);

void setPosition(SDL_Rect *pPosition, int x, int y, int h, int w);

void setUITextureToPosition(SDL_Renderer *renderer, UIElement uiElement, int x, int y);


// region map

int readMap(char *mapPath, Tile ***pMap, GameParameters *gameParameters);

void inititializeMapArray(FILE *fmap, Tile ***pMap, GameParameters *parameters );

void readMapArray(Tile **map, char height, char width );

#endif