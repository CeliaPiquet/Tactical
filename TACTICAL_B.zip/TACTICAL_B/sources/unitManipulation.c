#include "game.h"


// unit manipulation

// creates new unit with selected Job and gives its pointer to the HQ tile
void placeNewUnitOnHQ(Job *selectedJob, Tile ***pMap, char playerId, GameParameters parameters) {
    Unit *newUnit = malloc(sizeof(Unit));
    if (newUnit == NULL) {
        printf("\n erreur d'allocation newUnit");
    } else {
        newUnit->owner = playerId;
        newUnit->attacked = 1;
        newUnit->moved = 1;
        newUnit->injuries = 0;
        newUnit->job = selectedJob;
        if (playerId == 1) {
            (*pMap)[parameters.QG1y][parameters.QG1x].unit = newUnit;
        } else if (playerId == 2) {
            (*pMap)[parameters.QG2y][parameters.QG2x].unit = newUnit;
        }
    }
}


// if owned unit can still move or attack, processes move and attack options, for display, and future attempt to move or attack
void onStartSelectionMode(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters, char playerId) { 
    if(selectedUnit->owner == playerId) {
        if(!selectedUnit->moved) {
            findAllReachableTiles(selectedTile, map, selectedUnit, parameters);
        }
        if(!selectedUnit->attacked) {
            processAttackableTiles(selectedTile, map, selectedUnit, parameters);
        }
    }
}

// moves unit form ont tile to another and exhausts unit movepoints
// selectedUnitX and Y are coordonates of tile of origin 
void onMoveUnit(Unit *selectedUnit, Tile *selectedTile, Tile ***map, int *selectedUnitX, int *selectedUnitY) {

    (*map)[selectedTile->y][selectedTile->x].unit = (*map)[*selectedUnitY][*selectedUnitX].unit;
    (*map)[*selectedUnitY][*selectedUnitX].unit = NULL;

    (*map)[selectedTile->y][selectedTile->x].unit->moved= 1;
    
    *selectedUnitX = selectedTile->x;
    *selectedUnitY = selectedTile->y;
}


// try to attack unit
// if unit has too much injuries, is destroyed
// NB: if we set a variable attack value to units, this is where we would add this attack value to the injuries (instead of ++)
void onAttackUnit(Unit *selectedUnit, Tile *selectedTile , char *pIsSelectingUnit, Tile ***map, int selectedUnitX, int selectedUnitY) {
    if (selectedTile->attackable) {
        selectedTile->unit->injuries ++;
        if (selectedTile->unit->injuries >= selectedTile->unit->job->maxHealth) {
            destroyUnit(selectedTile, map);
        }
        (*map)[selectedUnitY][selectedUnitX].unit->attacked = 1;
        *pIsSelectingUnit = 0;
    }
}


// free alocated space dedicated to unit
void destroyUnit(Tile *selectedTile, Tile ***map) {
    free((*map)[selectedTile->y][selectedTile->x].unit);
    (*map)[selectedTile->y][selectedTile->x].unit = NULL;
}



// sets tiles within reach to attackable
// NB: a diagonal means 2 in reachability
void processAttackableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters) {
    int i, j;

    int sum;
    
    for( i = 0; i < parameters.mapHeight; i++) {
        for( j = 0; j < parameters.mapWidth; j++) {
            if ( i != selectedTile->y || j != selectedTile->x ) {
                if ( (*map)[i][j].moveCost != -1 ) {
                    sum = abs(i - selectedTile->y) + abs(j - selectedTile->x);
                    if(sum <= selectedUnit->job->maxRange && (*map)[i][j].unit != NULL) {   
                        if ((*map)[i][j].unit->owner != selectedUnit->owner) {
                            (*map)[i][j].attackable = 1;
                        } else {
                            (*map)[i][j].attackable = 0;
                        }
                    } else {
                        (*map)[i][j].attackable = 0;
                    }
                }
            }
        }
    }
}



                // PATHFINFING

// resets and callculates all move costs from origin with Dijkstra algorithm, then set tiles reachable from unit
void findAllReachableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters) {
    resetAllTotalMoveCosts(selectedTile, map, parameters);
    setAllTotalMoveCosts(map, parameters);
    displayAllTotalMoveCosts(*map, parameters);
    processReachableTiles(selectedTile, map, selectedUnit, parameters);
}


// set all tiles total cost to "infinity" while set the start point to 0 so we can start the Dijkstra
void resetAllTotalMoveCosts(Tile *selectedTile, Tile ***map, GameParameters parameters) {
    int i, j;
    for( i = 0; i < parameters.mapHeight; i++) {
        for( j = 0; j < parameters.mapWidth; j++) {
            if (i == selectedTile->y && j == selectedTile->x) {
                (*map)[i][j].totalMoveCost = 0;
            } else {
                (*map)[i][j].totalMoveCost = INT_MAX;
            }
        }
    }
}

// while we still can find a tile with minimum cost that has not been set, we set its neighbor total move cost
void setAllTotalMoveCosts(Tile ***map, GameParameters parameters) {
    int minX, minY;
    while (findMinimumCostTile(&minX, &minY, *map, parameters)) {
        setNeighborTilesCosts(minX, minY, map, parameters);
    }
}


// finds the coordinates of the tile with the minimum totalcost value and is not already checked
// NB: checked means you have set the totalcost of your neighbor tiles, and haven't seen your totalCost value reduced (which means we should re-check the neighbors costs)
char findMinimumCostTile(int *minX, int *minY, Tile **map,GameParameters parameters) {
    int minimumCost = INT_MAX;
    int i, j, minI, minJ;
    for( i = 0; i < parameters.mapHeight; i++) {
        for( j = 0; j < parameters.mapWidth; j++) {
            if (map[i][j].totalMoveCost < minimumCost && map[i][j].checked == 0) {
                minimumCost = map[i][j].totalMoveCost;
                minI = i;
                minJ = j;
            }
        }
    }
    if (minimumCost == INT_MAX) {
        return 0;
    } else {
        *minX = minJ;
        *minY = minI;
        return 1;
    }
}


// checks neighbors of an observed Tile to try to set their total move cost
// then set "checked" to 1
void setNeighborTilesCosts(int minX, int minY, Tile ***map, GameParameters parameters) {
    int cost = (*map)[minY][minX].totalMoveCost;
    setSingleNeighborTileCost(cost, minX, minY - 1, map, parameters);
    setSingleNeighborTileCost(cost, minX, minY + 1, map, parameters);
    setSingleNeighborTileCost(cost, minX - 1, minY, map, parameters);
    setSingleNeighborTileCost(cost, minX + 1, minY, map, parameters);
    (*map)[minY][minX].checked = 1;
}

// set the total move cost of a tile (based on the total move cost of its observed neighbor)
// it means that if the new calculated total move cost is lower than the former, it is the new cost. (otherwise, nothing happens)
// resets checked attribute to 0, if has already been checked 
void setSingleNeighborTileCost(int cost, int x, int y, Tile ***map, GameParameters parameters) {
    if (isTileAccessible(x, y, *map, parameters)) {
        if ((*map)[y][x].totalMoveCost > cost + (*map)[y][x].moveCost ) {
            (*map)[y][x].totalMoveCost = cost + (*map)[y][x].moveCost;
            (*map)[y][x].checked = 0;
        }
    }
}



// check if tile is ABSOLUTELY inaccessible (nothing to do with total MoveCosts)
// inncaccessible means not in map, or not reachable by default (water tile) or occupied
char isTileAccessible(int x, int y, Tile **map, GameParameters parameters) {
    if (x < 0 || y < 0) {
        return 0;
    } else if (x >= parameters.mapWidth || y >= parameters.mapHeight) {
        return 0;
    } else if (map[y][x].moveCost == -1){
        return 0;
    } else if (map[y][x].unit != NULL) {
        return 0;
    } else {
        return 1;
    }
}


//test purposes...
void displayAllTotalMoveCosts(Tile **map, GameParameters parameters) {
    int i, j;
    for( i = 0; i < parameters.mapHeight; i++) {
        printf("\n");
        for( j = 0; j < parameters.mapWidth; j++) {
            printf("%d\t", map[i][j].totalMoveCost);
        }
    }
}

// sets to reachable any tile which total move cost isn't higher than the unit movepoints (and not the unit tile itself)
void processReachableTiles(Tile *selectedTile, Tile ***map, Unit *selectedUnit, GameParameters parameters) {
    int i, j;
    for( i = 0; i < parameters.mapHeight; i++) {
        for( j = 0; j < parameters.mapWidth; j++) {
            if ((*map)[i][j].totalMoveCost <= selectedUnit->job->movePoints && !(selectedTile->x == j && selectedTile->y == i)) {
                (*map)[i][j].reachable = 1;
            }
        }
    }
}
